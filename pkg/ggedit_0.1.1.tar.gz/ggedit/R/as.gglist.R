#' @export
#' @keywords internal
as.gglist=function(p) structure(p, class=c("gglist", "ggplot"))