#' @title themeTips
#' @name themeTips
#' @description List of HTML tips for the theme BS modal.
#'
#' @docType data
#'
#' @usage data(themeTips)
#'
#' @format An object of class \code{"list"}
#'
#' @keywords datasets
#'
#'
#' @examples
#' data(themeTips)
#' themeTips
NULL